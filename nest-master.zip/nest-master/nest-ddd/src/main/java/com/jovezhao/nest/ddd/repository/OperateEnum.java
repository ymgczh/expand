package com.jovezhao.nest.ddd.repository;

public enum OperateEnum {
     save, remove
}
