package com.jovezhao.nest.ddd;

/**
 * Created by Jove on 2016-03-31.
 */
public abstract class AbstractRole<A extends EntityObject> extends BaseRole<A,StringIdentifier> {



}
