package com.jovezhao.nest.test.api;

/**
 * Created by zhaofujun on 2017/6/16.
 */
public interface UserService {
    String changeName(String name);
}
